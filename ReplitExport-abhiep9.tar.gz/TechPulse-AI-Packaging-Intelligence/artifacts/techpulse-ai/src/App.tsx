import { type ReactNode } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import { ErrorBoundary } from '@/components/error-boundary';
import { Route, Switch, useLocation, Router as WouterRouter } from 'wouter';
import { AppShell } from '@/components/AppShell';
import { AboutPage, AnalyticsPage, AssistantPage, Dashboard, HistoryPage, MaterialsPage, RecommendationPage, RiskAnalysisPage, SettingsPage } from '@/pages/Pages';

const queryClient = new QueryClient();

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function Router() {
  return <AppShell><RoutedErrorBoundary><Switch>
    <Route path="/" component={Dashboard} />
    <Route path="/recommendation" component={RecommendationPage} />
    <Route path="/risk-analysis" component={RiskAnalysisPage} />
    <Route path="/materials" component={MaterialsPage} />
    <Route path="/analytics" component={AnalyticsPage} />
    <Route path="/history" component={HistoryPage} />
    <Route path="/assistant" component={AssistantPage} />
    <Route path="/about" component={AboutPage} />
    <Route path="/settings" component={SettingsPage} />
    <Route component={Dashboard} />
  </Switch></RoutedErrorBoundary></AppShell>;
}

function App() {
  return <QueryClientProvider client={queryClient}><TooltipProvider><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><Router /></WouterRouter><Toaster /></TooltipProvider></QueryClientProvider>;
}

export default App;