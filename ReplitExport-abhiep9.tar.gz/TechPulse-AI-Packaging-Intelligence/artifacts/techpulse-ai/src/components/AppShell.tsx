import { BarChart3, BookOpen, Boxes, ChevronRight, ClipboardList, FlaskConical, Home, Info, Menu, Moon, Settings, ShieldAlert, Sun, X } from 'lucide-react';
import { Link, useLocation } from 'wouter';
import { useEffect, useState, type ReactNode } from 'react';

const navigation = [
  { href: '/', label: 'Overview', icon: Home },
  { href: '/recommendation', label: 'Recommendation', icon: FlaskConical },
  { href: '/risk-analysis', label: 'Risk analysis', icon: ShieldAlert },
  { href: '/materials', label: 'Material library', icon: Boxes },
  { href: '/analytics', label: 'Demo analytics', icon: BarChart3 },
  { href: '/history', label: 'Analysis history', icon: ClipboardList },
];
const secondary = [
  { href: '/assistant', label: 'Packaging assistant', icon: BookOpen },
  { href: '/about', label: 'Architecture & sources', icon: Info },
  { href: '/settings', label: 'Settings', icon: Settings },
];

export function AppShell({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [dark, setDark] = useState(() => localStorage.getItem('techpulse-theme') === 'dark');
  useEffect(() => { document.documentElement.classList.toggle('dark', dark); localStorage.setItem('techpulse-theme', dark ? 'dark' : 'light'); }, [dark]);
  useEffect(() => setMobileOpen(false), [location]);
  return <div className="app-shell noise">
    <aside className={`fixed inset-y-0 left-0 z-30 w-[262px] border-r border-border/80 bg-card/85 backdrop-blur-xl transition-transform duration-300 md:translate-x-0 ${mobileOpen ? 'translate-x-0' : '-translate-x-full'}`}>
      <div className="flex h-full flex-col px-4 py-5">
        <div className="mb-9 flex items-center justify-between px-3">
          <Link href="/" className="flex items-center gap-3" data-testid="link-brand">
            <span className="grid h-9 w-9 place-items-center rounded-xl bg-primary text-primary-foreground"><span className="font-display text-lg font-bold">T</span></span>
            <span><span className="block font-display text-[17px] font-bold tracking-tight">TechPulse</span><span className="font-mono-app text-[9px] uppercase tracking-[.18em] text-muted-foreground">AI / PACKAGING LAB</span></span>
          </Link>
          <button className="rounded-lg p-2 text-muted-foreground md:hidden" onClick={() => setMobileOpen(false)} aria-label="Close navigation" data-testid="button-close-navigation"><X size={18} /></button>
        </div>
        <div className="mb-2 px-3 font-mono-app text-[10px] uppercase tracking-[.18em] text-muted-foreground">Workspace</div>
        <nav className="space-y-1">{navigation.map(({ href, label, icon: Icon }) => <Link key={href} href={href} data-testid={`link-nav-${label.toLowerCase().replaceAll(' ', '-')}`} className={`group flex items-center gap-3 rounded-xl px-3 py-2.5 text-[13px] font-semibold transition-colors ${location === href ? 'bg-primary text-primary-foreground shadow-sm' : 'text-muted-foreground hover:bg-secondary hover:text-foreground'}`}><Icon size={17} strokeWidth={1.8} /><span>{label}</span>{location === href && <ChevronRight size={14} className="ml-auto opacity-70" />}</Link>)}</nav>
        <div className="mb-2 mt-8 px-3 font-mono-app text-[10px] uppercase tracking-[.18em] text-muted-foreground">Reference</div>
        <nav className="space-y-1">{secondary.map(({ href, label, icon: Icon }) => <Link key={href} href={href} data-testid={`link-nav-${label.toLowerCase().replaceAll(' ', '-')}`} className={`flex items-center gap-3 rounded-xl px-3 py-2.5 text-[13px] font-semibold transition-colors ${location === href ? 'bg-secondary text-foreground' : 'text-muted-foreground hover:bg-secondary hover:text-foreground'}`}><Icon size={17} strokeWidth={1.8} /><span>{label}</span></Link>)}</nav>
        <div className="mt-auto rounded-xl border border-border bg-secondary/55 p-3">
          <div className="mb-2 flex items-center gap-2"><span className="h-2 w-2 rounded-full bg-primary" /><span className="font-mono-app text-[10px] uppercase tracking-wider text-muted-foreground">Local prototype</span></div>
          <p className="text-[11px] leading-relaxed text-muted-foreground">Reference data and deterministic scoring. Validate with lab testing before production decisions.</p>
        </div>
        <button onClick={() => setDark(!dark)} className="mt-3 flex items-center gap-3 rounded-xl px-3 py-2.5 text-[12px] font-semibold text-muted-foreground hover:bg-secondary hover:text-foreground" data-testid="button-toggle-theme">{dark ? <Sun size={16} /> : <Moon size={16} />} {dark ? 'Light interface' : 'Dark interface'}</button>
      </div>
    </aside>
    {mobileOpen && <button className="fixed inset-0 z-20 bg-foreground/20 md:hidden" onClick={() => setMobileOpen(false)} aria-label="Close menu overlay" data-testid="button-menu-overlay" />}
    <main className="min-h-[100dvh] md:pl-[262px]">
      <header className="sticky top-0 z-10 flex h-16 items-center justify-between border-b border-border/70 bg-background/75 px-5 backdrop-blur-xl md:px-9">
        <button className="rounded-lg p-2 text-muted-foreground md:hidden" onClick={() => setMobileOpen(true)} aria-label="Open navigation" data-testid="button-open-navigation"><Menu size={20} /></button>
        <div className="hidden font-mono-app text-[10px] uppercase tracking-[.18em] text-muted-foreground md:block">Decision support / 2026 demo build</div>
        <div className="ml-auto flex items-center gap-3"><span className="hidden rounded-full border border-primary/20 bg-primary/5 px-3 py-1 font-mono-app text-[10px] text-primary sm:inline-flex">LOCAL ENGINE ONLINE</span><span className="h-2 w-2 rounded-full bg-accent" /></div>
      </header>
      <div className="mx-auto max-w-[1440px] px-5 py-7 md:px-9 md:py-10">{children}</div>
    </main>
    <div className="fixed bottom-0 left-0 right-0 z-20 flex h-[60px] items-center justify-around border-t border-border bg-card/95 px-2 backdrop-blur md:hidden">{navigation.slice(0, 5).map(({ href, label, icon: Icon }) => <Link key={href} href={href} className={`flex flex-col items-center gap-1 px-2 py-2 text-[9px] ${location === href ? 'text-primary' : 'text-muted-foreground'}`} data-testid={`mobile-nav-${label.toLowerCase().replaceAll(' ', '-')}`}><Icon size={18} /><span>{label.split(' ')[0]}</span></Link>)}</div>
  </div>;
}

export function PageHeading({ eyebrow, title, description, action }: { eyebrow: string; title: ReactNode; description: string; action?: ReactNode }) {
  return <div className="mb-8 flex flex-col justify-between gap-5 md:flex-row md:items-end"><div><div className="mb-2 font-mono-app text-[10px] uppercase tracking-[.2em] text-primary">{eyebrow}</div><h1 className="font-display text-3xl font-bold tracking-[-.04em] md:text-[42px]">{title}</h1><p className="mt-2 max-w-2xl text-sm leading-relaxed text-muted-foreground">{description}</p></div>{action && <div className="shrink-0">{action}</div>}</div>;
}