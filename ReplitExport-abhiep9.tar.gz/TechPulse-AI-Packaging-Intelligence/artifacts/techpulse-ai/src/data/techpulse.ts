export type Mode = 'Smart Auto-Profile' | 'Custom / Expert Input' | 'Image-Assisted Analysis';
export type Level = 'Low' | 'Moderate' | 'High' | 'Critical';

export type CommodityProfile = {
  commodity: string;
  moistureRange: string | null;
  fatRange: string | null;
  moistureSensitivity: 'Low' | 'Medium' | 'High';
  oxygenSensitivity: 'Low' | 'Medium' | 'High';
  lightSensitivity: 'Low' | 'Medium' | 'High';
  storage: string;
  barrierRequirements: string[];
  confidence: number;
  dataSource: string;
};

export type Material = {
  id: string;
  name: string;
  family: string;
  moisture: number;
  oxygen: number;
  light: number;
  fat: number;
  heat: number;
  mechanical: number;
  transparency: number;
  recyclability: number;
  compostability: number;
  cost: number;
  sustainability: number;
  applications: string[];
  advantages: string[];
  limitations: string[];
  color: string;
};

export type AnalysisProfile = {
  mode: Mode;
  commodity: string;
  shelfLife: number;
  storage: string;
  protections: string[];
  moisture?: number;
  fat?: number;
  costPriority: number;
  sustainabilityPriority: number;
};

export type Recommendation = {
  material: Material;
  compatibility: number;
  explanation: string;
  confidence: number;
};

export type RiskResult = {
  moisture: number;
  oxidation: number;
  light: number;
  physical: number;
  heat: number;
  overall: number;
  level: Level;
  explanations: string[];
  mitigations: string[];
};

export const commodities: CommodityProfile[] = [
  { commodity: 'Basmati rice', moistureRange: '10–13%', fatRange: '<1%', moistureSensitivity: 'Medium', oxygenSensitivity: 'Low', lightSensitivity: 'Low', storage: 'Ambient / dry', barrierRequirements: ['Moisture control', 'Puncture resistance'], confidence: 0.91, dataSource: 'Reference: FSSAI + ICAR storage guidance' },
  { commodity: 'Ground coffee', moistureRange: '<5%', fatRange: '12–16%', moistureSensitivity: 'High', oxygenSensitivity: 'High', lightSensitivity: 'High', storage: 'Ambient / dry', barrierRequirements: ['High oxygen barrier', 'Aroma retention', 'Light protection'], confidence: 0.94, dataSource: 'Reference: Coffee quality literature' },
  { commodity: 'Turmeric powder', moistureRange: '6–10%', fatRange: '8–10%', moistureSensitivity: 'Medium', oxygenSensitivity: 'Medium', lightSensitivity: 'High', storage: 'Ambient / dry', barrierRequirements: ['Light protection', 'Moisture control'], confidence: 0.89, dataSource: 'Reference: Spices Board quality guidance' },
  { commodity: 'Whole wheat flour', moistureRange: '11–14%', fatRange: '1–3%', moistureSensitivity: 'High', oxygenSensitivity: 'Medium', lightSensitivity: 'Low', storage: 'Ambient / dry', barrierRequirements: ['Moisture control', 'Seal integrity'], confidence: 0.88, dataSource: 'Reference: CIPHET food packaging studies' },
  { commodity: 'Roasted peanuts', moistureRange: '2–5%', fatRange: '42–50%', moistureSensitivity: 'Medium', oxygenSensitivity: 'High', lightSensitivity: 'Medium', storage: 'Ambient / dry', barrierRequirements: ['Oxygen barrier', 'Fat resistance', 'Puncture resistance'], confidence: 0.92, dataSource: 'Reference: NIFTEM shelf-life studies' },
  { commodity: 'Dehydrated mango', moistureRange: '12–18%', fatRange: '<1%', moistureSensitivity: 'High', oxygenSensitivity: 'Medium', lightSensitivity: 'Medium', storage: 'Ambient / dry', barrierRequirements: ['Moisture control', 'Light protection'], confidence: 0.86, dataSource: 'Reference: Post-harvest technology literature' },
  { commodity: 'Paneer', moistureRange: '45–55%', fatRange: '20–27%', moistureSensitivity: 'High', oxygenSensitivity: 'Medium', lightSensitivity: 'Low', storage: 'Chilled', barrierRequirements: ['Seal integrity', 'Fat resistance', 'Low-temperature performance'], confidence: 0.84, dataSource: 'Reference: Dairy packaging studies' },
  { commodity: 'Cold-pressed oil', moistureRange: null, fatRange: '99%+', moistureSensitivity: 'Low', oxygenSensitivity: 'High', lightSensitivity: 'High', storage: 'Ambient / dark', barrierRequirements: ['Light protection', 'Oxygen control', 'Fat resistance'], confidence: 0.9, dataSource: 'Reference: Oil oxidation standards' },
];

const materialRows: Material[] = [
  ['PET', 'Rigid polymer', 88, 78, 72, 88, 80, 92, 78, 78, 4, 58, ['Oil, spices, snacks'], ['Clear and tough', 'Excellent forming'], ['Limited heat-fill ceiling']],
  ['HDPE', 'Rigid polymer', 86, 70, 66, 86, 84, 90, 8, 80, 3, 62, ['Grains, powders, dairy'], ['Strong and chemical resistant', 'Low cost'], ['Opaque by default']],
  ['PP', 'Rigid polymer', 82, 72, 68, 84, 92, 88, 18, 76, 3, 59, ['Retort, dairy, snacks'], ['Strong heat resistance', 'Lightweight'], ['Moderate oxygen barrier']],
  ['LDPE', 'Flexible polymer', 92, 42, 34, 92, 72, 68, 8, 54, 2, 48, ['Bread, flour liners'], ['Excellent sealability', 'Flexible'], ['Weak oxygen and light barrier']],
  ['EVOH laminate', 'Multilayer', 96, 97, 82, 90, 78, 84, 4, 38, 7, 39, ['Coffee, oxygen-sensitive foods'], ['Very high oxygen barrier', 'Aroma retention'], ['Barrier drops at high humidity']],
  ['Metallized PET', 'Multilayer', 95, 94, 99, 88, 76, 82, 2, 35, 6, 43, ['Coffee, spices, oils'], ['Light and oxygen shield', 'Thin structure'], ['Harder to recycle']],
  ['Aluminium foil', 'Metal foil', 99, 99, 99, 96, 88, 74, 0, 72, 8, 45, ['Coffee, retort, oils'], ['Near-total barrier', 'Fat resistant'], ['Puncture sensitive']],
  ['Paperboard + PE', 'Fiber laminate', 78, 48, 28, 72, 58, 76, 0, 62, 4, 67, ['Dry goods, cartons'], ['Print-friendly', 'Good stiffness'], ['Not curbside-recyclable as composite']],
  ['Kraft paper', 'Fiber', 32, 12, 8, 38, 45, 66, 0, 86, 3, 84, ['Secondary packs, dry goods'], ['Renewable fiber', 'Low footprint'], ['Needs coating for moisture']],
  ['Coated paper', 'Fiber laminate', 68, 34, 18, 62, 54, 70, 0, 74, 4, 76, ['Bakery, powders'], ['Paper feel', 'Better grease holdout'], ['Coating limits recycling']],
  ['Glass', 'Inorganic', 99, 99, 90, 99, 92, 96, 92, 92, 7, 61, ['Oils, preserves, sauces'], ['Inert and premium', 'Reusable'], ['Heavy and breakable']],
  ['Tinplate', 'Metal', 99, 99, 94, 98, 95, 93, 0, 78, 7, 56, ['Cans, oils, retort'], ['Robust barrier', 'High heat tolerance'], ['Higher forming energy']],
  ['PLA', 'Biopolymer', 56, 28, 22, 50, 42, 58, 34, 64, 6, 72, ['Dry goods, short shelf life'], ['Bio-based feedstock', 'Clear'], ['Low heat and barrier performance']],
  ['Cellulose film', 'Fiber film', 64, 52, 26, 46, 48, 50, 76, 72, 5, 78, ['Bakery, dry snacks'], ['Compostable variants', 'Good print surface'], ['Humidity-sensitive']],
].map((row, index) => ({
  id: `mat-${index + 1}`, name: row[0] as string, family: row[1] as string, moisture: row[2] as number, oxygen: row[3] as number, light: row[4] as number, fat: row[5] as number, heat: row[6] as number, mechanical: row[7] as number, transparency: row[8] as number, recyclability: row[9] as number, compostability: row[10] as number, cost: row[11] as number, sustainability: row[12] as number, applications: row[13] as string[], advantages: row[14] as string[], limitations: row[15] as string[], color: ['#1f766f', '#d97535', '#536783', '#997b4a'][index % 4],
}));

export const materials: Material[] = materialRows;

export const defaultProfile: AnalysisProfile = {
  mode: 'Smart Auto-Profile', commodity: 'Ground coffee', shelfLife: 180, storage: 'Ambient / dry',
  protections: ['Moisture control', 'Oxygen barrier', 'Light protection'], costPriority: 45, sustainabilityPriority: 55,
};

export const getCommodity = (name: string) => commodities.find((c) => c.commodity === name) ?? commodities[0];
export const getMaterial = (name: string) => materials.find((m) => m.name === name) ?? materials[0];
const level = (value: number): Level => value >= 76 ? 'Critical' : value >= 51 ? 'High' : value >= 26 ? 'Moderate' : 'Low';

export function calculateRecommendations(profile: AnalysisProfile): Recommendation[] {
  const commodity = getCommodity(profile.commodity);
  const priorities = profile.protections.join(' ').toLowerCase();
  return materials.map((material) => {
    const barrier = ((commodity.moistureSensitivity === 'High' ? material.moisture : 100 - material.moisture) * .24)
      + ((commodity.oxygenSensitivity === 'High' ? material.oxygen : 100 - material.oxygen) * .24)
      + ((commodity.lightSensitivity === 'High' ? material.light : 100 - material.light) * .13)
      + material.mechanical * .12 + material.fat * .1 + material.heat * .07;
    const priorityBonus = (priorities.includes('oxygen') ? material.oxygen : 0) * .04 + (priorities.includes('light') ? material.light : 0) * .04;
    const preference = (100 - material.cost) * (profile.costPriority / 100) * .08 + material.sustainability * (profile.sustainabilityPriority / 100) * .06;
    const compatibility = Math.min(99, Math.max(32, Math.round(barrier * .68 + priorityBonus + preference)));
    const reasons = [
      material.oxygen > 80 ? 'strong oxygen control' : material.oxygen > 55 ? 'moderate oxygen control' : 'limited oxygen control',
      material.moisture > 80 ? 'reliable moisture barrier' : material.mechanical > 80 ? 'good mechanical protection' : 'lightweight format',
    ];
    return { material, compatibility, explanation: `${material.name} offers ${reasons[0]} with ${reasons[1]}. Scoring reflects the selected commodity sensitivities and priorities.`, confidence: Math.round(commodity.confidence * 100) };
  }).sort((a, b) => b.compatibility - a.compatibility).slice(0, 5);
}

export function calculateRisk(commodityName: string, materialName: string, shelfLife: number, storage: string): RiskResult {
  const c = getCommodity(commodityName);
  const m = getMaterial(materialName);
  const moisture = Math.min(98, Math.round((c.moistureSensitivity === 'High' ? 92 : c.moistureSensitivity === 'Medium' ? 58 : 26) + Math.max(0, 72 - m.moisture) * .32 + (storage === 'Humid' ? 13 : 0)));
  const oxidation = Math.min(98, Math.round((c.oxygenSensitivity === 'High' ? 86 : c.oxygenSensitivity === 'Medium' ? 54 : 22) + Math.max(0, 78 - m.oxygen) * .34 + shelfLife / 30));
  const light = Math.min(98, Math.round((c.lightSensitivity === 'High' ? 82 : c.lightSensitivity === 'Medium' ? 48 : 16) + Math.max(0, 74 - m.light) * .32));
  const physical = Math.min(98, Math.round(34 + Math.max(0, 72 - m.mechanical) * .34 + (shelfLife > 180 ? 8 : 0)));
  const heat = Math.min(98, Math.round(24 + Math.max(0, 70 - m.heat) * .38 + (storage === 'Hot-fill' ? 19 : 0)));
  const overall = Math.round(moisture * .25 + oxidation * .28 + light * .16 + physical * .16 + heat * .15);
  return {
    moisture, oxidation, light, physical, heat, overall, level: level(overall),
    explanations: [`${c.commodity} has ${c.moistureSensitivity.toLowerCase()} moisture sensitivity; ${m.name} scores ${m.moisture}/100 for moisture barrier.`, `Shelf-life target of ${shelfLife} days increases the exposure window for oxygen-driven quality loss.`, `${storage} storage changes the thermal and humidity assumptions used in this prototype model.`],
    mitigations: [m.oxygen < 75 ? 'Add an EVOH or foil barrier layer to reduce oxygen ingress.' : 'Validate seal integrity and oxygen transmission rate on the selected format.', m.light < 60 ? 'Use an opaque outer layer or secondary carton.' : 'Run light-exposure validation with the filled pack.', m.mechanical < 75 ? 'Add corner protection and drop-test the filled pack.' : 'Confirm closure torque and transit vibration performance.'],
  };
}

export const levelColor = (value: number) => value >= 76 ? '#b84c3b' : value >= 51 ? '#d97535' : value >= 26 ? '#b18a38' : '#1f766f';