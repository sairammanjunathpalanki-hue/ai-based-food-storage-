# TechPulse AI

An explainable, local decision-support workspace for recommending food packaging materials and predicting packaging failure risks.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/techpulse-ai/src/data/techpulse.ts` — commodity/material reference data and deterministic recommendation/risk algorithms
- `artifacts/techpulse-ai/src/pages/Pages.tsx` — routed product surfaces and local-storage-backed flows
- `artifacts/techpulse-ai/src/components/AppShell.tsx` — shared navigation shell and theme toggle
- `artifacts/techpulse-ai/src/index.css` — application theme, layout utilities, and visual tokens

## Architecture decisions

- The first product build is frontend-only so the core demo works without paid APIs, credentials, or a database.
- Recommendation and risk outputs are deterministic and transparent; all reference data and scoring weights live in the local data module.
- Analysis history and application preferences use browser localStorage and are intentionally not tied to an account.
- Image-assisted analysis is explicitly a demo workflow and does not claim real computer vision.

## Product

TechPulse AI supports Smart Auto-Profile, Custom / Expert Input, and Image-Assisted Analysis. It ranks 14 packaging materials, predicts moisture/oxidation/light/physical/heat risks, explains the score, supports material comparison, charts, history, report download, and a local packaging assistant.

## User preferences

No user or profile system; keep the application standalone and avoid personal names, avatars, greetings, or account settings.

## Gotchas

- Keep the prototype disclaimer visible when adding new recommendation or risk surfaces; reference values are not laboratory measurements or regulatory certification.
- The artifact workflow supplies `PORT` and `BASE_PATH`; use the managed workflow rather than starting Vite directly for preview verification.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
